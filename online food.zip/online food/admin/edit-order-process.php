<?php

include "databaseconnect.php";


$value = $_POST["value"];
 $address = $_POST["address"];

 $Quantity = $_POST["Quantity"];
$orderId = $_POST["orderId"]; 
$Notification = $_POST["Notification"]; 



$stmt=$conn->prepare("update  tblorders set value=:value,address=:address,Quantity=:Quantity,Notification=:Notification where orderId=:orderId");

	$stmt->bindParam(":orderId",$orderId);

	$stmt->bindParam(":value",$value);

	$stmt->bindParam(":address",$address);

	$stmt->bindParam(":Quantity",$Quantity);
	
	$stmt->bindParam(":Notification",$Notification);

	$stmt->execute();


		header("location:all-orders.php?msg=1");

		exit;

?>