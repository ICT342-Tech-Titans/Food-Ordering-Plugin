<?php
include "databaseconnect.php";
$orderId=$_REQUEST["orderId"];
$stmt1=$conn->prepare("delete from tblorders where orderId=:orderId");
$stmt1->bindParam(":orderId",$orderId);
$stmt1->execute();
	$stmt1=null;
	$conn=null;
header("location:all-orders.php?msg=2");
?>