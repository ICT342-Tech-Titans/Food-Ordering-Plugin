<?php

include "databaseconnect.php";

?>

<?php

$emailId  = trim($_REQUEST["emailId"]);

$Pass = trim($_REQUEST["Pass"]);







	$stmt=$conn->prepare("select * from tbladmin where emailId=:emailId && Pass=:Pass");

	$stmt->bindparam(":emailId", $emailId);	

	$stmt->bindparam(":Pass", $Pass);	

	

	$stmt->execute();

	

	echo $count=$stmt->rowcount();

	$row=$stmt->fetch();

	if($count>0) 

	{

		

		

		session_start();

		echo $_SESSION["adminId"] 	= $row["adminId"]; 

		header("location:dashboard.php?msg=1");

		exit;

		

	}

	else

	{

		$conn=null;

		$stmt=null;

		header("location:index.php?err=1");

		exit;

	}

	

	$_SESSION["emailId"] = null; 

	$_SESSION["Pass"] 	 = null;

	exit;

	



?>

