<?php

include "databaseconnect.php";





 $banner=$_FILES['banner']['name']; 

 $expbanner=explode('.',$banner);

 $bannerexptype=$expbanner[1];

 date_default_timezone_set('Australia/Melbourne');

 $date = date('m/d/Yh:i:sa', time());

 $rand=rand(10000,99999);

 $encname=$date.$rand;

 $bannerpath="itemimage/".$banner;

 move_uploaded_file($_FILES["banner"]["tmp_name"],$bannerpath);



  

$image = $_FILES['banner']['name']; 

$ItemName = $_POST["ItemName"];

$Price = $_POST["Price"];

$ItemId = $_POST["ItemId"];

$addedDateTime		=	date("F j, Y, g:i a"); 


$stmt=$conn->prepare("update  tblitems set image=:image,ItemName=:ItemName,Price=:Price,addedDateTime =:addedDateTime where ItemId=:ItemId");

	$stmt->bindParam(":ItemId",$ItemId);

	$stmt->bindParam(":image",$image);

	$stmt->bindParam(":ItemName",$ItemName);

	$stmt->bindParam(":Price",$Price);

	$stmt->bindParam(":addedDateTime",$addedDateTime);

	$stmt->execute();


		header("location:all-items.php?msg=1");

		exit;

?>