<?php
include "databaseconnect.php";
$ItemId=$_REQUEST["ItemId"];
$stmt1=$conn->prepare("delete from tblitems where ItemId=:ItemId");
$stmt1->bindParam(":ItemId",$ItemId);
$stmt1->execute();
	$stmt1=null;
	$conn=null;
header("location:all-items.php?msg=2");
?>